create table if not exists psk_keys (keyid text primary key, key blob);
.quit


